package org.freeplane.features.link;

public enum ArrowType {
	DEFAULT, NONE;
}
